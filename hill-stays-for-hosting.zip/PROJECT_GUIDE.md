# 🏔️ HillStays — Project Guide

A complete guide to the HillStays web application: what it is, what's inside,
and how to use, run, and host it.

> **In one line:** HillStays is a website where tourists discover homestays,
> attractions, things to do, food, and travel info for **Kalimpong & Darjeeling** —
> and where you (the admin) manage all the listings from a simple web page.

---

## 1. Project Details

| | |
|---|---|
| **Project name** | HillStays |
| **Type** | Web application (runs in a browser) |
| **Purpose** | Tourism discovery platform for Kalimpong & Darjeeling |
| **Audience** | Tourists (visitors) + an internal admin (you/your team) |
| **Current phase** | Phase 1 MVP — *Discovery + Contact* |
| **Booking model** | "Request to book" via WhatsApp/Call (online payment comes in a later phase) |
| **Tech stack** | Next.js 15, React 19, TypeScript, Tailwind CSS |
| **Data storage** | JSON file (`data/listings.json`), seeded from built-in sample data |
| **Project folder** | `C:\Users\prati\Projects\hill-stays` |

### What the app can do today
- Browse listings in **5 categories**: 🏡 Homestays, 🏔️ Attractions, 🥾 Things to Do, 🍜 Food & Cafes, 🚐 How to Reach
- **Search & filter** by destination (Kalimpong / Darjeeling), keyword, and price
- View rich **detail pages** with photos, descriptions, ratings, and details
- **Contact a homestay** instantly via WhatsApp or phone
- **Admin panel** to add and delete listings — no coding required
- **Mobile-first** design and **SEO-friendly** pages (so Google can find you)

---

## 2. The Pages (Sitemap)

| Page | URL | What it shows |
|------|-----|----------------|
| Home | `/` | Hero, search bar, categories, top-rated listings |
| Homestays | `/homestays` | All homestays + filters |
| Attractions | `/attractions` | Viewpoints, monasteries, etc. |
| Things to Do | `/activities` | Treks, rafting, toy train, etc. |
| Food & Cafes | `/food` | Restaurants and cafes |
| How to Reach | `/transport` | Routes, jeeps, fares |
| Listing detail | `/homestays/pine-view-homestay` (example) | Full info for one listing |
| **Admin** | `/admin` | Login → add / delete listings |

---

## 3. How to Use the App

### 👤 As a tourist (visitor)
1. Open the website (the home page).
2. Use the **search bar** to pick a destination and type a keyword, **or** click a
   category tile (e.g. "Homestays").
3. On a category page, narrow results using the **destination chips** and the
   **search / price** filters.
4. Click any card to open its **detail page**.
5. On a homestay page, tap **"Request on WhatsApp"** or **"Call host"** to enquire.
   *(No payment is taken — this is a contact/enquiry, by design.)*

### 🔑 As the admin (you)
1. Go to **`/admin`** (there's also an "Admin" link in the website footer).
2. Enter the admin password.
   - **Default password:** `admin123`
   - **Change it:** see *Security* below. **Please change it before going public.**
3. You'll see the **dashboard** with two sections:

   **➕ Add a new listing (left side)**
   - Choose a **Category** and **Destination** first.
   - The form automatically shows the right fields for that category
     (e.g. price/guests for a homestay, route/fare for transport).
   - Fill in the details. Required fields are marked with a red `*`.
   - **Image URLs**: paste one or more web links to photos, separated by commas.
     Leave blank to use a placeholder image.
   - Click **"Add listing"**. It appears on the public site immediately.

   **🗂️ Existing listings (right side)**
   - See every listing with its category and location.
   - Click **"View"** to open its public page, or **"Delete"** to remove it
     (you'll be asked to confirm).

4. Click **"Log out"** when you're done.

> 💡 **Tip:** The default sample listings (Pine View Homestay, Deolo Hill, etc.) are
> just examples. Delete them and add your real listings, or edit the defaults in
> `src/lib/seed.ts`.

---

## 4. How to Run It (on your computer)

You need **Node.js** installed (already set up on this machine).

```bash
# 1. Open the project folder
cd C:\Users\prati\Projects\hill-stays

# 2. Install dependencies (first time only)
npm install

# 3. Start the app
npm run dev
```

Then open **http://localhost:3000** in your browser.

To stop the app, press **Ctrl + C** in the terminal.

**Other commands:**
```bash
npm run build   # make an optimized production build
npm start       # run the production build (after npm run build)
```

---

## 5. Hosting It Online

The project is fully self-contained in one folder. A ready-to-upload zip is at:
`C:\Users\prati\Projects\hill-stays-for-hosting.zip`

Any Node.js host runs it with the same 3 steps: `npm install` → `npm run build` → `npm start`.

| Host | Works as-is? | Note |
|------|-------------|------|
| **Render / Railway** | ✅ Yes | Admin panel works (writable disk) |
| Your own VPS / server | ✅ Yes | Admin panel works |
| **Vercel / Netlify** | ⚠️ Partly | Site works, but the admin "add listing" won't persist — needs a database first |

> The admin panel saves to a file (`data/listings.json`). Vercel/Netlify have a
> read-only filesystem, so to use them you'd move listings to a database
> (a planned next step).

---

## 6. Security

- The admin area is protected by a password. The **default is `admin123`** — fine for
  testing, **not safe for public use**.
- **To change it:** create a file named `.env.local` in the project root containing:
  ```
  ADMIN_PASSWORD=your-strong-password-here
  ```
  Then restart the app. Keep this password private.

---

## 7. Project Structure (for reference)

```
hill-stays/
├── PROJECT_GUIDE.md          # this document
├── README.md                 # quick technical readme
├── package.json              # project info & dependencies
├── data/listings.json        # your listings (auto-created, editable via /admin)
└── src/
    ├── app/
    │   ├── page.tsx                  # home page
    │   ├── [category]/page.tsx       # category listing pages
    │   ├── [category]/[slug]/page.tsx# listing detail pages
    │   ├── admin/page.tsx            # admin dashboard
    │   └── api/admin/...             # admin login / create / delete endpoints
    ├── components/                   # reusable UI (cards, header, forms...)
    └── lib/
        ├── types.ts          # data model (what a Homestay/Attraction looks like)
        ├── seed.ts           # the default sample listings
        ├── store.ts          # reads/writes the listings file
        ├── data.ts           # search & query helpers used by pages
        ├── admin.ts          # password check + form validation
        └── routes.ts         # URL ↔ category mapping
```

**Where things live:**
- **To add/remove listings:** use the **admin panel** (`/admin`).
- **To change the default sample listings:** edit `src/lib/seed.ts`, then delete
  `data/listings.json` so it regenerates.
- **To change colors/branding:** `tailwind.config.ts` and the components in `src/components/`.

---

## 8. Roadmap (what's planned next)

| Phase | What | Status |
|-------|------|--------|
| **1 — Discovery + Contact** | Listings, search, filters, admin panel | ✅ Done (this) |
| **2 — Accounts & Reviews** | Tourist login, favorites, ratings | Planned |
| **3 — Booking & Payment** | Availability calendar, online payment (Razorpay) | Planned |
| **4 — Growth** | Homestay owners self-register, bilingual, analytics | Planned |

**Recommended next step before public launch:** move listings from the JSON file to a
free database (e.g. Supabase) so the admin panel works on any host, including Vercel.

---

## 9. Quick FAQ

**Q: Do tourists need an account to browse?**
No. Anyone can browse and contact homestays freely. Accounts come in Phase 2.

**Q: Can tourists pay online?**
Not yet — Phase 1 uses WhatsApp/Call enquiries. Online payment is Phase 3.

**Q: Are the photos and phone numbers real?**
No — the sample listings use placeholder photos and dummy phone numbers.
Replace them with real ones via the admin panel.

**Q: Will I lose my listings if I restart the app?**
No. They're saved in `data/listings.json` on disk. (The exception is read-only hosts
like Vercel — see Hosting.)

**Q: How do I reset everything to the original samples?**
Delete the `data` folder and restart — it rebuilds from `src/lib/seed.ts`.

---

*Built with Next.js. This guide lives at `PROJECT_GUIDE.md` in the project folder.*
