import type { Listing, Homestay, Category, Destination } from "./types";
import { readAll } from "./store";

// ---------------------------------------------------------------------------
// Query helpers. Pages call these instead of touching the store directly, so
// swapping the JSON store for a real database later only means changing store.ts.
// ---------------------------------------------------------------------------

export function getAllListings(): Listing[] {
  return readAll();
}

export function getByCategory(category: Category): Listing[] {
  return readAll().filter((l) => l.category === category);
}

export function getListing(category: Category, slug: string): Listing | undefined {
  return readAll().find((l) => l.category === category && l.slug === slug);
}

export function getDestinations(): Destination[] {
  return ["Kalimpong", "Darjeeling"];
}

export interface ListingFilters {
  destination?: Destination;
  category?: Category;
  query?: string;
  maxPrice?: number;
}

export function searchListings(filters: ListingFilters): Listing[] {
  return readAll().filter((l) => {
    if (filters.category && l.category !== filters.category) return false;
    if (filters.destination && l.destination !== filters.destination) return false;
    if (filters.query) {
      const q = filters.query.toLowerCase();
      const haystack = `${l.name} ${l.area} ${l.shortDescription}`.toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    if (filters.maxPrice && l.category === "homestay") {
      if ((l as Homestay).pricePerNight > filters.maxPrice) return false;
    }
    return true;
  });
}

export function getFeatured(): Listing[] {
  // Highest-rated few, for the homepage.
  return [...readAll()]
    .filter((l) => l.rating)
    .sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0))
    .slice(0, 6);
}
