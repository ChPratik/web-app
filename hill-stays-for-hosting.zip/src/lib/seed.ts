import type {
  Listing,
  Homestay,
  Attraction,
  Activity,
  Food,
  Transport,
} from "./types";

// ---------------------------------------------------------------------------
// SEED DATA
// In Phase 1 (MVP) listings live here so the site works with zero setup.
// In Phase 3 this is replaced by a PostgreSQL database; the page code that
// reads these arrays via the helpers at the bottom won't need to change much.
// Images are royalty-free Unsplash photos used as placeholders.
// ---------------------------------------------------------------------------

const img = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1200&q=70`;

const homestays: Homestay[] = [
  {
    id: "h1",
    slug: "pine-view-homestay",
    category: "homestay",
    name: "Pine View Homestay",
    destination: "Kalimpong",
    area: "Deolo Hill",
    shortDescription: "Cosy family homestay with sweeping Kanchenjunga views from every room.",
    description:
      "Perched on Deolo Hill, Pine View is a warm family-run homestay surrounded by pine forest and flower gardens. Wake up to clear views of Mt. Kanchenjunga, enjoy home-cooked Nepali meals, and unwind on the sunny terrace. A 10-minute drive from Kalimpong town centre.",
    images: [img("photo-1501785888041-af3ef285b470"), img("photo-1564013799919-ab600027ffc6")],
    rating: 4.8,
    reviewCount: 42,
    pricePerNight: 1800,
    maxGuests: 4,
    bedrooms: 2,
    amenities: ["WiFi", "Parking", "Mountain View", "Meals Included", "Garden", "Hot Water"],
    hostName: "Sunita Pradhan",
    contactPhone: "+919800000001",
  },
  {
    id: "h2",
    slug: "orchid-retreat",
    category: "homestay",
    name: "Orchid Retreat",
    destination: "Kalimpong",
    area: "Dr. Graham's Homes",
    shortDescription: "Heritage bungalow stay surrounded by Kalimpong's famous orchid nurseries.",
    description:
      "A restored colonial-era bungalow near Dr. Graham's Homes, Orchid Retreat blends old-world charm with modern comfort. Spacious rooms, a library lounge, and a garden bursting with orchids. Ideal for couples and quiet getaways.",
    images: [img("photo-1505693416388-ac5ce068fe85"), img("photo-1522708323590-d24dbb6b0267")],
    rating: 4.6,
    reviewCount: 28,
    pricePerNight: 2600,
    maxGuests: 3,
    bedrooms: 2,
    amenities: ["WiFi", "Parking", "Meals Included", "Garden", "Pet Friendly"],
    hostName: "Anil Rai",
    contactPhone: "+919800000002",
  },
  {
    id: "h3",
    slug: "tiger-hill-cottage",
    category: "homestay",
    name: "Tiger Hill Cottage",
    destination: "Darjeeling",
    area: "Tiger Hill",
    shortDescription: "Minutes from the famous sunrise point — perfect for early risers.",
    description:
      "Located close to the legendary Tiger Hill sunrise viewpoint, this cottage lets you skip the early-morning traffic. Snug wood-panelled rooms, hot tea on arrival, and a host who knows every shortcut. A short ride from Darjeeling Mall.",
    images: [img("photo-1571896349842-33c89424de2d"), img("photo-1512917774080-9991f1c4c750")],
    rating: 4.7,
    reviewCount: 55,
    pricePerNight: 2200,
    maxGuests: 5,
    bedrooms: 3,
    amenities: ["WiFi", "Parking", "Mountain View", "Hot Water", "Breakfast"],
    hostName: "Pemba Sherpa",
    contactPhone: "+919800000003",
  },
  {
    id: "h4",
    slug: "tea-garden-stay",
    category: "homestay",
    name: "Tea Garden Stay",
    destination: "Darjeeling",
    area: "Happy Valley",
    shortDescription: "Live inside a working tea estate with guided plucking tours.",
    description:
      "Set within the Happy Valley tea estate, this homestay offers a rare chance to stay among the tea bushes. Join a morning plucking tour, watch the leaves being processed, and sip the freshest Darjeeling tea you'll ever taste.",
    images: [img("photo-1597318181409-cf64d0b5d8a2"), img("photo-1582719478250-c89cae4dc85b")],
    rating: 4.9,
    reviewCount: 37,
    pricePerNight: 3000,
    maxGuests: 4,
    bedrooms: 2,
    amenities: ["WiFi", "Parking", "Meals Included", "Tea Tour", "Mountain View"],
    hostName: "Dawa Lama",
    contactPhone: "+919800000004",
  },
];

const attractions: Attraction[] = [
  {
    id: "a1",
    slug: "deolo-hill",
    category: "attraction",
    name: "Deolo Hill",
    destination: "Kalimpong",
    area: "Deolo",
    shortDescription: "Kalimpong's highest point with panoramic valley and river views.",
    description:
      "At 1,704 m, Deolo Hill is the highest point in Kalimpong. The landscaped park offers 360° views of the Relli and Teesta valleys, a garden, and paragliding take-off points on clear days.",
    images: [img("photo-1626621341517-bbf3d9990a23")],
    rating: 4.5,
    reviewCount: 120,
    bestTimeToVisit: "October to March (clear skies)",
    entryFee: "₹20 per person",
  },
  {
    id: "a2",
    slug: "batasia-loop",
    category: "attraction",
    name: "Batasia Loop",
    destination: "Darjeeling",
    area: "Ghoom",
    shortDescription: "Spiral railway loop with a war memorial and Kanchenjunga backdrop.",
    description:
      "The Batasia Loop is a spiral section of the Darjeeling Himalayan Railway where the toy train makes a complete loop. The surrounding garden and Gorkha war memorial frame stunning views of Kanchenjunga.",
    images: [img("photo-1544735716-392fe2489ffa")],
    rating: 4.6,
    reviewCount: 210,
    bestTimeToVisit: "Early morning",
    entryFee: "₹30 per person",
  },
];

const activities: Activity[] = [
  {
    id: "ac1",
    slug: "teesta-river-rafting",
    category: "activity",
    name: "Teesta River Rafting",
    destination: "Kalimpong",
    area: "Teesta Bazaar",
    shortDescription: "Grade II–IV white-water rafting on the Teesta river.",
    description:
      "Take on the rapids of the Teesta river with experienced guides and full safety gear. Stretches range from gentle family floats to grade IV thrills. Best enjoyed from October to June.",
    images: [img("photo-1530866495561-507c9faab2ed")],
    rating: 4.7,
    reviewCount: 64,
    durationHours: 3,
    priceFrom: 800,
  },
  {
    id: "ac2",
    slug: "darjeeling-toy-train-joyride",
    category: "activity",
    name: "Toy Train Joyride",
    destination: "Darjeeling",
    area: "Darjeeling Station",
    shortDescription: "UNESCO heritage steam train ride from Darjeeling to Ghoom.",
    description:
      "Ride the famous Darjeeling Himalayan Railway 'toy train' on the joyride circuit to Ghoom, the highest railway station in India, with a stop at Batasia Loop. A nostalgic, must-do experience.",
    images: [img("photo-1602940659805-770d1b3b9911")],
    rating: 4.8,
    reviewCount: 188,
    durationHours: 2,
    priceFrom: 1500,
  },
];

const foods: Food[] = [
  {
    id: "f1",
    slug: "gompus-restaurant",
    category: "food",
    name: "Gompu's Restaurant",
    destination: "Darjeeling",
    area: "Chowk Bazaar",
    shortDescription: "Legendary spot for jumbo pork momos and Tibetan classics.",
    description:
      "A Darjeeling institution since the 1930s, Gompu's is famous for its oversized momos, thukpa, and hearty Tibetan-Nepali fare in a cosy old-town setting.",
    images: [img("photo-1496116218417-1a781b1c416c")],
    rating: 4.4,
    reviewCount: 95,
    cuisine: ["Tibetan", "Nepali", "Chinese"],
    priceForTwo: 500,
  },
  {
    id: "f2",
    slug: "kalimpong-cafe-kalsang",
    category: "food",
    name: "Cafe Kalsang",
    destination: "Kalimpong",
    area: "Main Road",
    shortDescription: "Warm cafe serving Tibetan comfort food and filter coffee.",
    description:
      "A favourite among travellers, Cafe Kalsang dishes up steaming thenthuk, momos, and strong coffee with a friendly mountain vibe right on Kalimpong's main road.",
    images: [img("photo-1559925393-8be0ec4767c8")],
    rating: 4.3,
    reviewCount: 51,
    cuisine: ["Tibetan", "Continental"],
    priceForTwo: 450,
  },
];

const transports: Transport[] = [
  {
    id: "t1",
    slug: "njp-to-darjeeling-shared-jeep",
    category: "transport",
    name: "NJP / Siliguri → Darjeeling",
    destination: "Darjeeling",
    area: "NJP Station",
    shortDescription: "Shared jeeps run regularly from NJP and Siliguri to Darjeeling.",
    description:
      "The most common way to reach Darjeeling. Shared jeeps depart from NJP railway station and Siliguri's Tenzing Norgay terminus through the day. Book the front seat early for the best views.",
    images: [img("photo-1469854523086-cc02fe5d8800")],
    routeFrom: "NJP / Siliguri",
    routeTo: "Darjeeling",
    mode: "Shared Jeep",
    approxFare: "₹250–350 per seat",
    approxDuration: "3–3.5 hours",
  },
  {
    id: "t2",
    slug: "siliguri-to-kalimpong-shared-jeep",
    category: "transport",
    name: "Siliguri → Kalimpong",
    destination: "Kalimpong",
    area: "Siliguri",
    shortDescription: "Frequent shared jeeps along the scenic Teesta river road.",
    description:
      "Shared jeeps to Kalimpong leave from Siliguri throughout the day, following the beautiful Teesta river valley road. A reserved taxi is also available for groups.",
    images: [img("photo-1485827404703-89b55fcc595e")],
    routeFrom: "Siliguri",
    routeTo: "Kalimpong",
    mode: "Shared Jeep / Taxi",
    approxFare: "₹200–300 per seat",
    approxDuration: "2.5–3 hours",
  },
];

// The seed listings ship with the app. On first run the store copies these
// into a writable JSON file; after that the store is the source of truth and
// the admin panel can add/remove listings freely.
export const SEED_LISTINGS: Listing[] = [
  ...homestays,
  ...attractions,
  ...activities,
  ...foods,
  ...transports,
];
