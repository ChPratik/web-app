import type {
  Listing,
  Category,
  Destination,
  Homestay,
  Attraction,
  Activity,
  Food,
  Transport,
} from "./types";
import { slugExists } from "./store";

// Admin password. Override by setting ADMIN_PASSWORD in .env.local.
// ⚠️ Change this before deploying anywhere public.
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";

/** Validate the password sent by the admin UI (via the x-admin-password header). */
export function isAuthorized(req: Request): boolean {
  const header = req.headers.get("x-admin-password");
  return header === ADMIN_PASSWORD;
}

const VALID_CATEGORIES: Category[] = [
  "homestay",
  "attraction",
  "activity",
  "food",
  "transport",
];
const VALID_DESTINATIONS: Destination[] = ["Kalimpong", "Darjeeling"];

function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

function splitList(value: unknown): string[] {
  if (typeof value !== "string") return [];
  return value
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function num(value: unknown): number | undefined {
  if (value === undefined || value === null || value === "") return undefined;
  const n = Number(value);
  return Number.isFinite(n) ? n : undefined;
}

type Input = Record<string, unknown>;

/**
 * Build a fully-typed Listing from raw form input, or return an error string.
 * `id` and `slug` are generated here; everything else comes from the form.
 */
export function buildListing(input: Input): { listing?: Listing; error?: string } {
  const category = String(input.category || "") as Category;
  if (!VALID_CATEGORIES.includes(category)) {
    return { error: "Please choose a valid category." };
  }

  const name = String(input.name || "").trim();
  if (!name) return { error: "Name is required." };

  const destination = String(input.destination || "") as Destination;
  if (!VALID_DESTINATIONS.includes(destination)) {
    return { error: "Please choose Kalimpong or Darjeeling." };
  }

  const area = String(input.area || "").trim();
  if (!area) return { error: "Area / locality is required." };

  const shortDescription = String(input.shortDescription || "").trim();
  const description = String(input.description || "").trim() || shortDescription;
  if (!shortDescription) return { error: "Short description is required." };

  const slug = slugify(name);
  if (!slug) return { error: "Could not generate a URL from that name." };
  if (slugExists(category, slug)) {
    return { error: `A ${category} with a similar name already exists.` };
  }

  const images = splitList(input.images);
  const cover =
    images.length > 0
      ? images
      : ["https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=70"];

  const base = {
    id: `${category[0]}_${slug}_${cover.length}${name.length}`,
    slug,
    category,
    name,
    destination,
    area,
    shortDescription,
    description,
    images: cover,
    rating: num(input.rating),
    reviewCount: num(input.reviewCount),
  };

  switch (category) {
    case "homestay": {
      const pricePerNight = num(input.pricePerNight);
      if (pricePerNight === undefined) return { error: "Price per night is required for homestays." };
      const listing: Homestay = {
        ...base,
        category: "homestay",
        pricePerNight,
        maxGuests: num(input.maxGuests) ?? 2,
        bedrooms: num(input.bedrooms) ?? 1,
        amenities: splitList(input.amenities),
        hostName: String(input.hostName || "").trim() || "Host",
        contactPhone: String(input.contactPhone || "").trim(),
      };
      if (!listing.contactPhone) return { error: "Contact phone is required for homestays." };
      return { listing };
    }
    case "attraction": {
      const listing: Attraction = {
        ...base,
        category: "attraction",
        bestTimeToVisit: String(input.bestTimeToVisit || "").trim() || undefined,
        entryFee: String(input.entryFee || "").trim() || undefined,
      };
      return { listing };
    }
    case "activity": {
      const listing: Activity = {
        ...base,
        category: "activity",
        durationHours: num(input.durationHours),
        priceFrom: num(input.priceFrom),
      };
      return { listing };
    }
    case "food": {
      const listing: Food = {
        ...base,
        category: "food",
        cuisine: splitList(input.cuisine),
        priceForTwo: num(input.priceForTwo),
      };
      return { listing };
    }
    case "transport": {
      const listing: Transport = {
        ...base,
        category: "transport",
        routeFrom: String(input.routeFrom || "").trim(),
        routeTo: String(input.routeTo || "").trim(),
        mode: String(input.mode || "").trim() || "Shared Jeep",
        approxFare: String(input.approxFare || "").trim() || undefined,
        approxDuration: String(input.approxDuration || "").trim() || undefined,
      };
      return { listing };
    }
    default:
      return { error: "Unsupported category." };
  }
}
