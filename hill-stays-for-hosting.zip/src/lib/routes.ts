import { CATEGORY_META, type Category } from "./types";

// Map a URL segment (e.g. "homestays") back to its Category (e.g. "homestay").
const SEGMENT_TO_CATEGORY: Record<string, Category> = Object.entries(
  CATEGORY_META
).reduce((acc, [category, meta]) => {
  acc[meta.urlSegment] = category as Category;
  return acc;
}, {} as Record<string, Category>);

export function segmentToCategory(segment: string): Category | undefined {
  return SEGMENT_TO_CATEGORY[segment];
}

export function allCategorySegments(): string[] {
  return Object.values(CATEGORY_META).map((m) => m.urlSegment);
}
