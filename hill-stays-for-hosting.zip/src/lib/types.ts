// Core data model for the Kalimpong & Darjeeling tourism platform.
// Phase 1 (MVP): everything is read from seed data in `data.ts`.
// Phase 3: these same types map cleanly to PostgreSQL tables + Prisma models.

export type Destination = "Kalimpong" | "Darjeeling";

export type Category = "homestay" | "attraction" | "activity" | "food" | "transport";

/** Fields shared by every listing, whatever its category. */
export interface BaseListing {
  id: string;
  slug: string;            // used in the URL, e.g. /kalimpong/homestays/pine-view
  category: Category;
  name: string;
  destination: Destination;
  area: string;            // neighbourhood / locality, e.g. "Deolo", "Tiger Hill"
  shortDescription: string;
  description: string;
  images: string[];        // first image is the cover
  rating?: number;         // 0–5, optional until reviews exist
  reviewCount?: number;
}

export interface Homestay extends BaseListing {
  category: "homestay";
  pricePerNight: number;   // INR
  maxGuests: number;
  bedrooms: number;
  amenities: string[];     // e.g. "WiFi", "Parking", "Mountain View", "Meals Included"
  hostName: string;
  contactPhone: string;    // used for the WhatsApp / call button in the MVP
}

export interface Attraction extends BaseListing {
  category: "attraction";
  bestTimeToVisit?: string;
  entryFee?: string;       // free-form, e.g. "Free" or "₹30 per person"
}

export interface Activity extends BaseListing {
  category: "activity";
  durationHours?: number;
  priceFrom?: number;      // INR, "from" price
}

export interface Food extends BaseListing {
  category: "food";
  cuisine: string[];       // e.g. "Tibetan", "Nepali", "Continental"
  priceForTwo?: number;    // INR
}

export interface Transport extends BaseListing {
  category: "transport";
  routeFrom: string;
  routeTo: string;
  mode: string;            // "Shared Jeep", "Taxi", "Toy Train"
  approxFare?: string;     // free-form
  approxDuration?: string;
}

export type Listing = Homestay | Attraction | Activity | Food | Transport;

export const CATEGORY_META: Record<
  Category,
  { label: string; plural: string; urlSegment: string; emoji: string }
> = {
  homestay: { label: "Homestay", plural: "Homestays", urlSegment: "homestays", emoji: "🏡" },
  attraction: { label: "Attraction", plural: "Attractions", urlSegment: "attractions", emoji: "🏔️" },
  activity: { label: "Activity", plural: "Things to Do", urlSegment: "activities", emoji: "🥾" },
  food: { label: "Food", plural: "Food & Cafes", urlSegment: "food", emoji: "🍜" },
  transport: { label: "Transport", plural: "How to Reach", urlSegment: "transport", emoji: "🚐" },
};
