import fs from "node:fs";
import path from "node:path";
import type { Listing } from "./types";
import { SEED_LISTINGS } from "./seed";

// ---------------------------------------------------------------------------
// Tiny JSON-file data store.
//
// This lets the admin panel add/remove listings at runtime without a database.
// On first access it writes the seed data to data/listings.json; after that the
// file is the source of truth.
//
// NOTE: this works great on a normal server / local machine. On serverless
// hosts with a read-only filesystem (e.g. Vercel) you'd swap this module for a
// real database (Postgres/Supabase) — the rest of the app calls the same
// helpers in data.ts and won't need to change.
// ---------------------------------------------------------------------------

const DATA_DIR = path.join(process.cwd(), "data");
const DATA_FILE = path.join(DATA_DIR, "listings.json");

function ensureFile(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(SEED_LISTINGS, null, 2), "utf-8");
  }
}

export function readAll(): Listing[] {
  ensureFile();
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(raw) as Listing[];
  } catch {
    return [...SEED_LISTINGS];
  }
}

export function writeAll(listings: Listing[]): void {
  ensureFile();
  fs.writeFileSync(DATA_FILE, JSON.stringify(listings, null, 2), "utf-8");
}

export function addListing(listing: Listing): void {
  const all = readAll();
  all.push(listing);
  writeAll(all);
}

export function deleteListing(id: string): boolean {
  const all = readAll();
  const next = all.filter((l) => l.id !== id);
  if (next.length === all.length) return false;
  writeAll(next);
  return true;
}

/** True if another listing in the same category already uses this slug. */
export function slugExists(category: string, slug: string): boolean {
  return readAll().some((l) => l.category === category && l.slug === slug);
}
