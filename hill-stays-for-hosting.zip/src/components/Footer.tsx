import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-gray-100 bg-gray-50 mt-12">
      <div className="mx-auto max-w-6xl px-4 py-8 text-sm text-gray-500">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <div className="font-bold text-brand-600 text-base">🏔️ HillStays</div>
            <p className="mt-1">Homestays &amp; travel in Kalimpong &amp; Darjeeling.</p>
          </div>
          <div className="flex gap-4">
            <Link href="/homestays" className="hover:text-brand-600">Homestays</Link>
            <Link href="/attractions" className="hover:text-brand-600">Attractions</Link>
            <Link href="/activities" className="hover:text-brand-600">Things to Do</Link>
            <Link href="/admin" className="hover:text-brand-600">Admin</Link>
          </div>
        </div>
        <p className="mt-6 text-xs text-gray-400">
          © {2026} HillStays · Demo MVP. Listings shown are sample data.
        </p>
      </div>
    </footer>
  );
}
