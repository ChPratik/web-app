"use client";

import { useState } from "react";
import { CATEGORY_META, type Category } from "@/lib/types";

const inputClass =
  "w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500";
const labelClass = "block text-xs font-medium text-gray-600 mb-1";

function Field({
  label,
  name,
  value,
  onChange,
  type = "text",
  placeholder,
  required,
  hint,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (name: string, value: string) => void;
  type?: string;
  placeholder?: string;
  required?: boolean;
  hint?: string;
}) {
  return (
    <div>
      <label className={labelClass}>
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <input
        className={inputClass}
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(name, e.target.value)}
      />
      {hint && <p className="text-[11px] text-gray-400 mt-1">{hint}</p>}
    </div>
  );
}

const categories: Category[] = ["homestay", "attraction", "activity", "food", "transport"];

export function AddListingForm({
  password,
  onCreated,
}: {
  password: string;
  onCreated: () => void;
}) {
  const [form, setForm] = useState<Record<string, string>>({
    category: "homestay",
    destination: "Kalimpong",
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const set = (name: string, value: string) =>
    setForm((f) => ({ ...f, [name]: value }));

  const category = (form.category || "homestay") as Category;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await fetch("/api/admin/listings", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-admin-password": password },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not create listing.");
      } else {
        setSuccess(`"${data.listing.name}" added successfully.`);
        setForm({ category, destination: form.destination || "Kalimpong" });
        onCreated();
      }
    } catch {
      setError("Network error — is the server running?");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Category + destination */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className={labelClass}>Category <span className="text-red-500">*</span></label>
          <select
            className={inputClass}
            value={form.category}
            onChange={(e) => set("category", e.target.value)}
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {CATEGORY_META[c].emoji} {CATEGORY_META[c].label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className={labelClass}>Destination <span className="text-red-500">*</span></label>
          <select
            className={inputClass}
            value={form.destination}
            onChange={(e) => set("destination", e.target.value)}
          >
            <option value="Kalimpong">Kalimpong</option>
            <option value="Darjeeling">Darjeeling</option>
          </select>
        </div>
      </div>

      {/* Common fields */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Field label="Name" name="name" value={form.name || ""} onChange={set} required placeholder="Pine View Homestay" />
        <Field label="Area / Locality" name="area" value={form.area || ""} onChange={set} required placeholder="Deolo Hill" />
      </div>
      <Field
        label="Short description"
        name="shortDescription"
        value={form.shortDescription || ""}
        onChange={set}
        required
        placeholder="One-line summary shown on cards"
      />
      <div>
        <label className={labelClass}>Full description</label>
        <textarea
          className={inputClass}
          rows={3}
          value={form.description || ""}
          onChange={(e) => set("description", e.target.value)}
          placeholder="Longer description for the detail page"
        />
      </div>
      <Field
        label="Image URLs"
        name="images"
        value={form.images || ""}
        onChange={set}
        placeholder="https://... , https://..."
        hint="Comma-separated. Leave blank to use a placeholder photo."
      />
      <div className="grid grid-cols-2 gap-3">
        <Field label="Rating (0–5)" name="rating" value={form.rating || ""} onChange={set} type="number" placeholder="4.5" />
        <Field label="Review count" name="reviewCount" value={form.reviewCount || ""} onChange={set} type="number" placeholder="20" />
      </div>

      {/* Category-specific fields */}
      <div className="rounded-lg bg-brand-50 p-3 space-y-3">
        <p className="text-xs font-semibold text-brand-700 uppercase tracking-wide">
          {CATEGORY_META[category].label} details
        </p>

        {category === "homestay" && (
          <>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Price / night ₹" name="pricePerNight" value={form.pricePerNight || ""} onChange={set} type="number" required />
              <Field label="Max guests" name="maxGuests" value={form.maxGuests || ""} onChange={set} type="number" />
              <Field label="Bedrooms" name="bedrooms" value={form.bedrooms || ""} onChange={set} type="number" />
            </div>
            <Field label="Amenities" name="amenities" value={form.amenities || ""} onChange={set} placeholder="WiFi, Parking, Mountain View" hint="Comma-separated" />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Host name" name="hostName" value={form.hostName || ""} onChange={set} />
              <Field label="Contact phone" name="contactPhone" value={form.contactPhone || ""} onChange={set} required placeholder="+9198..." hint="Used for WhatsApp/Call" />
            </div>
          </>
        )}

        {category === "attraction" && (
          <div className="grid grid-cols-2 gap-3">
            <Field label="Best time to visit" name="bestTimeToVisit" value={form.bestTimeToVisit || ""} onChange={set} placeholder="October to March" />
            <Field label="Entry fee" name="entryFee" value={form.entryFee || ""} onChange={set} placeholder="₹20 per person / Free" />
          </div>
        )}

        {category === "activity" && (
          <div className="grid grid-cols-2 gap-3">
            <Field label="Duration (hours)" name="durationHours" value={form.durationHours || ""} onChange={set} type="number" />
            <Field label="Price from ₹" name="priceFrom" value={form.priceFrom || ""} onChange={set} type="number" />
          </div>
        )}

        {category === "food" && (
          <div className="grid grid-cols-2 gap-3">
            <Field label="Cuisine" name="cuisine" value={form.cuisine || ""} onChange={set} placeholder="Tibetan, Nepali" hint="Comma-separated" />
            <Field label="Cost for two ₹" name="priceForTwo" value={form.priceForTwo || ""} onChange={set} type="number" />
          </div>
        )}

        {category === "transport" && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Route from" name="routeFrom" value={form.routeFrom || ""} onChange={set} placeholder="Siliguri" />
              <Field label="Route to" name="routeTo" value={form.routeTo || ""} onChange={set} placeholder="Kalimpong" />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Mode" name="mode" value={form.mode || ""} onChange={set} placeholder="Shared Jeep" />
              <Field label="Approx. fare" name="approxFare" value={form.approxFare || ""} onChange={set} placeholder="₹250" />
              <Field label="Approx. duration" name="approxDuration" value={form.approxDuration || ""} onChange={set} placeholder="3 hours" />
            </div>
          </>
        )}
      </div>

      {error && <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">{error}</p>}
      {success && <p className="text-sm text-green-700 bg-green-50 rounded-lg px-3 py-2">{success}</p>}

      <button
        type="submit"
        disabled={submitting}
        className="w-full rounded-lg bg-brand-600 hover:bg-brand-700 disabled:opacity-60 text-white font-semibold py-3 transition-colors"
      >
        {submitting ? "Adding..." : "Add listing"}
      </button>
    </form>
  );
}
