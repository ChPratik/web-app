import Link from "next/link";
import Image from "next/image";
import type { Listing, Homestay } from "@/lib/types";
import { CATEGORY_META } from "@/lib/types";

function priceLabel(listing: Listing): string | null {
  switch (listing.category) {
    case "homestay":
      return `₹${listing.pricePerNight.toLocaleString("en-IN")} / night`;
    case "activity":
      return listing.priceFrom ? `from ₹${listing.priceFrom.toLocaleString("en-IN")}` : null;
    case "food":
      return listing.priceForTwo ? `₹${listing.priceForTwo.toLocaleString("en-IN")} for two` : null;
    case "attraction":
      return listing.entryFee ?? null;
    case "transport":
      return listing.approxFare ?? null;
  }
}

export function ListingCard({ listing }: { listing: Listing }) {
  const meta = CATEGORY_META[listing.category];
  const href = `/${meta.urlSegment}/${listing.slug}`;
  const price = priceLabel(listing);

  return (
    <Link
      href={href}
      className="group block rounded-xl overflow-hidden border border-gray-100 bg-white shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="relative aspect-[4/3] bg-gray-100">
        <Image
          src={listing.images[0]}
          alt={listing.name}
          fill
          sizes="(max-width: 768px) 100vw, 33vw"
          className="object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <span className="absolute top-2 left-2 px-2 py-1 rounded-full bg-white/90 text-xs font-medium text-gray-700">
          {meta.emoji} {meta.label}
        </span>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-gray-900 leading-snug">{listing.name}</h3>
          {listing.rating && (
            <span className="shrink-0 text-sm font-medium text-amber-600">★ {listing.rating}</span>
          )}
        </div>
        <p className="text-sm text-gray-500 mt-0.5">
          {listing.area}, {listing.destination}
        </p>
        <p className="text-sm text-gray-600 mt-2 line-clamp-2">{listing.shortDescription}</p>
        {price && (
          <p className="mt-3 font-semibold text-brand-600">{price}</p>
        )}
      </div>
    </Link>
  );
}
