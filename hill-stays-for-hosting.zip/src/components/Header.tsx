import Link from "next/link";
import { CATEGORY_META } from "@/lib/types";

const navCategories = ["homestay", "attraction", "activity", "food", "transport"] as const;

export function Header() {
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-gray-100">
      <div className="mx-auto max-w-6xl px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 font-bold text-lg text-brand-600">
            <span className="text-2xl">🏔️</span>
            <span>HillStays</span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {navCategories.map((cat) => {
              const meta = CATEGORY_META[cat];
              return (
                <Link
                  key={cat}
                  href={`/${meta.urlSegment}`}
                  className="px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:text-brand-600 hover:bg-brand-50 transition-colors"
                >
                  {meta.plural}
                </Link>
              );
            })}
          </nav>
        </div>
        {/* Mobile category scroller */}
        <nav className="md:hidden flex gap-2 overflow-x-auto pb-3 -mx-1 px-1">
          {navCategories.map((cat) => {
            const meta = CATEGORY_META[cat];
            return (
              <Link
                key={cat}
                href={`/${meta.urlSegment}`}
                className="whitespace-nowrap px-3 py-1.5 rounded-full text-sm bg-brand-50 text-brand-700 font-medium"
              >
                {meta.emoji} {meta.plural}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
