import Link from "next/link";

// Simple GET-form search that lands on /homestays with query params.
// No client-side JS needed — works even on weak connections.
export function SearchBar() {
  return (
    <form
      action="/homestays"
      className="bg-white rounded-xl shadow-lg p-3 flex flex-col sm:flex-row gap-3"
    >
      <div className="flex-1">
        <label className="block text-xs font-medium text-gray-500 mb-1 px-1">Destination</label>
        <select
          name="destination"
          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-gray-900 focus:outline-none focus:ring-2 focus:ring-brand-500"
        >
          <option value="">Anywhere</option>
          <option value="Kalimpong">Kalimpong</option>
          <option value="Darjeeling">Darjeeling</option>
        </select>
      </div>
      <div className="flex-[2]">
        <label className="block text-xs font-medium text-gray-500 mb-1 px-1">Search</label>
        <input
          name="q"
          type="text"
          placeholder="e.g. mountain view, tea garden..."
          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-gray-900 focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
      </div>
      <div className="flex items-end">
        <button
          type="submit"
          className="w-full sm:w-auto rounded-lg bg-brand-600 hover:bg-brand-700 text-white font-semibold px-6 py-2 transition-colors"
        >
          Search
        </button>
      </div>
    </form>
  );
}

// Fallback link kept so the import is reachable in dev tooling.
export function BrowseAllLink() {
  return <Link href="/homestays">Browse all homestays</Link>;
}
