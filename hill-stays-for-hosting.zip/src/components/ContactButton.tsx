import type { Homestay } from "@/lib/types";

// Phase 1 booking = "request to book / contact" via WhatsApp + call.
// In Phase 3 this whole block is replaced by a real booking + payment flow.
export function ContactButton({ homestay }: { homestay: Homestay }) {
  const phoneDigits = homestay.contactPhone.replace(/[^0-9]/g, "");
  const message = encodeURIComponent(
    `Hi ${homestay.hostName}, I'm interested in booking "${homestay.name}" via HillStays. Is it available?`
  );
  const whatsappUrl = `https://wa.me/${phoneDigits}?text=${message}`;
  const telUrl = `tel:${homestay.contactPhone}`;

  return (
    <div className="rounded-xl border border-gray-100 shadow-sm p-5 bg-white">
      <div className="flex items-baseline justify-between">
        <span className="text-2xl font-bold text-gray-900">
          ₹{homestay.pricePerNight.toLocaleString("en-IN")}
        </span>
        <span className="text-gray-500 text-sm">per night</span>
      </div>
      <p className="text-sm text-gray-500 mt-1">
        Up to {homestay.maxGuests} guests · {homestay.bedrooms} bedrooms
      </p>

      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-4 flex items-center justify-center gap-2 w-full rounded-lg bg-green-600 hover:bg-green-700 text-white font-semibold py-3 transition-colors"
      >
        💬 Request on WhatsApp
      </a>
      <a
        href={telUrl}
        className="mt-2 flex items-center justify-center gap-2 w-full rounded-lg border border-gray-200 hover:border-gray-400 text-gray-800 font-semibold py-3 transition-colors"
      >
        📞 Call host
      </a>
      <p className="text-xs text-gray-400 mt-3 text-center">
        Hosted by {homestay.hostName}. You won&apos;t be charged yet — online payment
        comes in a later phase.
      </p>
    </div>
  );
}
