import { NextResponse } from "next/server";
import { readAll, addListing } from "@/lib/store";
import { isAuthorized, buildListing } from "@/lib/admin";

export const dynamic = "force-dynamic";

// List all listings (admin table).
export async function GET(req: Request) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  return NextResponse.json({ listings: readAll() });
}

// Create a new listing from submitted form data.
export async function POST(req: Request) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const { listing, error } = buildListing(body);
  if (error || !listing) {
    return NextResponse.json({ error: error ?? "Could not create listing." }, { status: 400 });
  }

  addListing(listing);
  return NextResponse.json({ listing }, { status: 201 });
}
