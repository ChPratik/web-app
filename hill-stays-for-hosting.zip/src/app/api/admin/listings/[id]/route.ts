import { NextResponse } from "next/server";
import { deleteListing } from "@/lib/store";
import { isAuthorized } from "@/lib/admin";

export const dynamic = "force-dynamic";

// Delete a listing by id.
export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  const removed = deleteListing(id);
  if (!removed) {
    return NextResponse.json({ error: "Listing not found." }, { status: 404 });
  }
  return NextResponse.json({ ok: true });
}
