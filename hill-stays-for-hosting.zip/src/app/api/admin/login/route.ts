import { NextResponse } from "next/server";
import { isAuthorized } from "@/lib/admin";

// Lets the admin UI verify a password before showing the dashboard.
export async function POST(req: Request) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }
  return NextResponse.json({ ok: true });
}
