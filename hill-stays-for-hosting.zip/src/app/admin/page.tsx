"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import type { Listing } from "@/lib/types";
import { CATEGORY_META } from "@/lib/types";
import { AddListingForm } from "@/components/admin/AddListingForm";

export default function AdminPage() {
  const [password, setPassword] = useState("");
  const [authed, setAuthed] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);

  const [listings, setListings] = useState<Listing[]>([]);
  const [loadingList, setLoadingList] = useState(false);

  // Restore a previously-entered password for this browser session.
  useEffect(() => {
    const saved = sessionStorage.getItem("hs_admin_pw");
    if (saved) {
      setPassword(saved);
      verify(saved);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadListings = useCallback(async (pw: string) => {
    setLoadingList(true);
    try {
      const res = await fetch("/api/admin/listings", {
        headers: { "x-admin-password": pw },
      });
      if (res.ok) {
        const data = await res.json();
        setListings(data.listings);
      }
    } finally {
      setLoadingList(false);
    }
  }, []);

  async function verify(pw: string) {
    setChecking(true);
    setLoginError(null);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "x-admin-password": pw },
      });
      if (res.ok) {
        setAuthed(true);
        sessionStorage.setItem("hs_admin_pw", pw);
        loadListings(pw);
      } else {
        setAuthed(false);
        setLoginError("Wrong password.");
        sessionStorage.removeItem("hs_admin_pw");
      }
    } catch {
      setLoginError("Could not reach the server.");
    } finally {
      setChecking(false);
    }
  }

  async function handleDelete(listing: Listing) {
    if (!confirm(`Delete "${listing.name}"? This cannot be undone.`)) return;
    const res = await fetch(`/api/admin/listings/${listing.id}`, {
      method: "DELETE",
      headers: { "x-admin-password": password },
    });
    if (res.ok) {
      setListings((prev) => prev.filter((l) => l.id !== listing.id));
    } else {
      alert("Could not delete listing.");
    }
  }

  function logout() {
    sessionStorage.removeItem("hs_admin_pw");
    setAuthed(false);
    setPassword("");
    setListings([]);
  }

  // ---- Login screen ----
  if (!authed) {
    return (
      <div className="mx-auto max-w-sm px-4 py-20">
        <h1 className="text-2xl font-bold text-gray-900">Admin login</h1>
        <p className="text-gray-500 text-sm mt-1">Manage HillStays listings.</p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            verify(password);
          }}
          className="mt-6 space-y-3"
        >
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Admin password"
            className="w-full rounded-lg border border-gray-200 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-brand-500"
          />
          {loginError && <p className="text-sm text-red-600">{loginError}</p>}
          <button
            type="submit"
            disabled={checking}
            className="w-full rounded-lg bg-brand-600 hover:bg-brand-700 disabled:opacity-60 text-white font-semibold py-2.5"
          >
            {checking ? "Checking..." : "Log in"}
          </button>
        </form>
        <p className="text-xs text-gray-400 mt-4">
          Default password is <code className="bg-gray-100 px-1 rounded">admin123</code> — change it via
          the <code className="bg-gray-100 px-1 rounded">ADMIN_PASSWORD</code> env variable.
        </p>
      </div>
    );
  }

  // ---- Dashboard ----
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Admin dashboard</h1>
          <p className="text-gray-500 text-sm">{listings.length} listings</p>
        </div>
        <div className="flex gap-2">
          <Link href="/" className="text-sm text-brand-600 underline px-2 py-2">
            View site
          </Link>
          <button onClick={logout} className="text-sm text-gray-500 hover:text-gray-800 px-2 py-2">
            Log out
          </button>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Add form */}
        <section>
          <h2 className="font-semibold text-gray-900 mb-3">Add a new listing</h2>
          <div className="rounded-xl border border-gray-100 p-5 shadow-sm">
            <AddListingForm password={password} onCreated={() => loadListings(password)} />
          </div>
        </section>

        {/* Existing listings */}
        <section>
          <h2 className="font-semibold text-gray-900 mb-3">Existing listings</h2>
          {loadingList ? (
            <p className="text-gray-500 text-sm">Loading…</p>
          ) : (
            <div className="space-y-2">
              {listings.map((l) => {
                const meta = CATEGORY_META[l.category];
                return (
                  <div
                    key={l.id}
                    className="flex items-center justify-between gap-3 rounded-lg border border-gray-100 px-3 py-2"
                  >
                    <div className="min-w-0">
                      <p className="font-medium text-gray-900 truncate">
                        {meta.emoji} {l.name}
                      </p>
                      <p className="text-xs text-gray-500 truncate">
                        {meta.label} · {l.area}, {l.destination}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Link
                        href={`/${meta.urlSegment}/${l.slug}`}
                        className="text-xs text-brand-600 underline"
                      >
                        View
                      </Link>
                      <button
                        onClick={() => handleDelete(l)}
                        className="text-xs text-red-600 hover:text-red-800 font-medium"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
