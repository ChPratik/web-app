import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const metadata: Metadata = {
  title: {
    default: "HillStays — Homestays & Travel in Kalimpong & Darjeeling",
    template: "%s | HillStays",
  },
  description:
    "Discover handpicked homestays, attractions, things to do, food and transport in Kalimpong and Darjeeling. Plan your perfect Himalayan getaway.",
  keywords: [
    "Kalimpong homestay",
    "Darjeeling homestay",
    "Kalimpong travel",
    "Darjeeling tourism",
    "homestays in Darjeeling",
  ],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col bg-white text-gray-900">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
