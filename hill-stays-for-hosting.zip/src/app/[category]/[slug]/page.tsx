import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { getListing } from "@/lib/data";
import { segmentToCategory } from "@/lib/routes";
import { CATEGORY_META, type Listing } from "@/lib/types";
import { ContactButton } from "@/components/ContactButton";

// Listings are editable at runtime via the admin panel, so render on demand
// and always read the latest data.
export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ category: string; slug: string }>;
}): Promise<Metadata> {
  const { category: segment, slug } = await params;
  const category = segmentToCategory(segment);
  if (!category) return {};
  const listing = getListing(category, slug);
  if (!listing) return {};
  return {
    title: `${listing.name} — ${listing.area}, ${listing.destination}`,
    description: listing.shortDescription,
    openGraph: { images: listing.images.slice(0, 1) },
  };
}

// Small key/value row used in the details panel.
function Detail({ label, value }: { label: string; value?: string | number }) {
  if (value === undefined || value === "") return null;
  return (
    <div className="flex justify-between py-2 border-b border-gray-100 last:border-0">
      <span className="text-gray-500">{label}</span>
      <span className="font-medium text-gray-900 text-right">{value}</span>
    </div>
  );
}

function CategoryDetails({ listing }: { listing: Listing }) {
  switch (listing.category) {
    case "homestay":
      return (
        <>
          <Detail label="Bedrooms" value={listing.bedrooms} />
          <Detail label="Max guests" value={listing.maxGuests} />
          <Detail label="Amenities" value={listing.amenities.join(", ")} />
        </>
      );
    case "attraction":
      return (
        <>
          <Detail label="Best time to visit" value={listing.bestTimeToVisit} />
          <Detail label="Entry fee" value={listing.entryFee} />
        </>
      );
    case "activity":
      return (
        <>
          <Detail label="Duration" value={listing.durationHours ? `${listing.durationHours} hrs` : undefined} />
          <Detail label="Price from" value={listing.priceFrom ? `₹${listing.priceFrom}` : undefined} />
        </>
      );
    case "food":
      return (
        <>
          <Detail label="Cuisine" value={listing.cuisine.join(", ")} />
          <Detail label="Cost for two" value={listing.priceForTwo ? `₹${listing.priceForTwo}` : undefined} />
        </>
      );
    case "transport":
      return (
        <>
          <Detail label="Route" value={`${listing.routeFrom} → ${listing.routeTo}`} />
          <Detail label="Mode" value={listing.mode} />
          <Detail label="Approx. fare" value={listing.approxFare} />
          <Detail label="Approx. duration" value={listing.approxDuration} />
        </>
      );
  }
}

export default async function ListingDetailPage({
  params,
}: {
  params: Promise<{ category: string; slug: string }>;
}) {
  const { category: segment, slug } = await params;
  const category = segmentToCategory(segment);
  if (!category) notFound();
  const listing = getListing(category, slug);
  if (!listing) notFound();

  const meta = CATEGORY_META[listing.category];

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      {/* Breadcrumb */}
      <nav className="text-sm text-gray-500 mb-4">
        <Link href="/" className="hover:text-brand-600">Home</Link>
        <span className="mx-2">/</span>
        <Link href={`/${segment}`} className="hover:text-brand-600">{meta.plural}</Link>
        <span className="mx-2">/</span>
        <span className="text-gray-700">{listing.name}</span>
      </nav>

      {/* Image gallery */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 rounded-xl overflow-hidden">
        {listing.images.map((src, i) => (
          <div
            key={i}
            className={`relative aspect-[16/10] bg-gray-100 ${
              listing.images.length === 1 ? "sm:col-span-2" : ""
            }`}
          >
            <Image
              src={src}
              alt={`${listing.name} photo ${i + 1}`}
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className="object-cover"
              priority={i === 0}
            />
          </div>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main content */}
        <div className="lg:col-span-2">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{listing.name}</h1>
              <p className="text-gray-500 mt-1">
                {meta.emoji} {listing.area}, {listing.destination}
              </p>
            </div>
            {listing.rating && (
              <span className="shrink-0 text-amber-600 font-semibold">
                ★ {listing.rating}
                {listing.reviewCount ? (
                  <span className="text-gray-400 font-normal text-sm"> ({listing.reviewCount})</span>
                ) : null}
              </span>
            )}
          </div>

          <p className="mt-5 text-gray-700 leading-relaxed whitespace-pre-line">
            {listing.description}
          </p>

          <div className="mt-6 rounded-xl border border-gray-100 p-4">
            <h2 className="font-semibold text-gray-900 mb-2">Details</h2>
            <CategoryDetails listing={listing} />
          </div>
        </div>

        {/* Sidebar: contact for homestays, info note otherwise */}
        <aside className="lg:col-span-1">
          <div className="lg:sticky lg:top-24">
            {listing.category === "homestay" ? (
              <ContactButton homestay={listing} />
            ) : (
              <div className="rounded-xl border border-gray-100 shadow-sm p-5 bg-brand-50">
                <p className="text-brand-700 font-medium">Planning your trip?</p>
                <p className="text-sm text-gray-600 mt-1">
                  Pair this with a nearby homestay for the full experience.
                </p>
                <Link
                  href="/homestays"
                  className="mt-3 inline-block rounded-lg bg-brand-600 hover:bg-brand-700 text-white font-semibold px-4 py-2 text-sm"
                >
                  Browse homestays
                </Link>
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
