import { notFound } from "next/navigation";
import Link from "next/link";
import type { Metadata } from "next";
import { ListingCard } from "@/components/ListingCard";
import { searchListings } from "@/lib/data";
import { segmentToCategory } from "@/lib/routes";
import { CATEGORY_META, type Destination } from "@/lib/types";

// Listings are editable at runtime via the admin panel, so render on demand.
export const dynamic = "force-dynamic";

type SearchParams = { destination?: string; q?: string; maxPrice?: string };

export async function generateMetadata({
  params,
}: {
  params: Promise<{ category: string }>;
}): Promise<Metadata> {
  const { category: segment } = await params;
  const category = segmentToCategory(segment);
  if (!category) return {};
  const meta = CATEGORY_META[category];
  return {
    title: `${meta.plural} in Kalimpong & Darjeeling`,
    description: `Browse ${meta.plural.toLowerCase()} across Kalimpong and Darjeeling on HillStays.`,
  };
}

export default async function CategoryPage({
  params,
  searchParams,
}: {
  params: Promise<{ category: string }>;
  searchParams: Promise<SearchParams>;
}) {
  const { category: segment } = await params;
  const sp = await searchParams;
  const category = segmentToCategory(segment);
  if (!category) notFound();

  const meta = CATEGORY_META[category];
  const destination = (sp.destination as Destination) || undefined;
  const query = sp.q || undefined;
  const maxPrice = sp.maxPrice ? Number(sp.maxPrice) : undefined;

  const results = searchListings({ category, destination, query, maxPrice });

  // Helper to build filter links that preserve the other active filters.
  const buildHref = (overrides: Partial<SearchParams>) => {
    const next = { destination, q: query, maxPrice: maxPrice?.toString(), ...overrides };
    const usp = new URLSearchParams();
    if (next.destination) usp.set("destination", next.destination);
    if (next.q) usp.set("q", next.q);
    if (next.maxPrice) usp.set("maxPrice", next.maxPrice);
    const qs = usp.toString();
    return `/${segment}${qs ? `?${qs}` : ""}`;
  };

  const destinations: (Destination | undefined)[] = [undefined, "Kalimpong", "Darjeeling"];

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900">
        {meta.emoji} {meta.plural}
      </h1>
      <p className="text-gray-500 mt-1">
        {results.length} {results.length === 1 ? "result" : "results"}
        {destination ? ` in ${destination}` : " in Kalimpong & Darjeeling"}
      </p>

      {/* Filters */}
      <div className="mt-5 space-y-4">
        {/* Destination chips */}
        <div className="flex flex-wrap gap-2">
          {destinations.map((d) => {
            const active = destination === d || (!destination && !d);
            return (
              <Link
                key={d ?? "all"}
                href={buildHref({ destination: d })}
                className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${
                  active
                    ? "bg-brand-600 text-white border-brand-600"
                    : "bg-white text-gray-700 border-gray-200 hover:border-brand-500"
                }`}
              >
                {d ?? "All destinations"}
              </Link>
            );
          })}
        </div>

        {/* Search + price (only price for homestays) */}
        <form action={`/${segment}`} className="flex flex-wrap gap-2 items-end">
          {destination && <input type="hidden" name="destination" value={destination} />}
          <div>
            <label className="block text-xs text-gray-500 mb-1">Search</label>
            <input
              name="q"
              defaultValue={query}
              placeholder="Keyword..."
              className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          {category === "homestay" && (
            <div>
              <label className="block text-xs text-gray-500 mb-1">Max price / night</label>
              <select
                name="maxPrice"
                defaultValue={maxPrice?.toString() ?? ""}
                className="rounded-lg border border-gray-200 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
              >
                <option value="">Any</option>
                <option value="2000">Under ₹2,000</option>
                <option value="2500">Under ₹2,500</option>
                <option value="3000">Under ₹3,000</option>
              </select>
            </div>
          )}
          <button
            type="submit"
            className="rounded-lg bg-gray-900 text-white text-sm font-medium px-4 py-2 hover:bg-gray-700"
          >
            Apply
          </button>
          {(query || maxPrice) && (
            <Link
              href={buildHref({ q: undefined, maxPrice: undefined })}
              className="text-sm text-gray-500 underline px-2 py-2"
            >
              Clear
            </Link>
          )}
        </form>
      </div>

      {/* Results */}
      {results.length === 0 ? (
        <div className="mt-12 text-center text-gray-500">
          <p className="text-lg">No {meta.plural.toLowerCase()} match your filters.</p>
          <Link href={`/${segment}`} className="text-brand-600 underline mt-2 inline-block">
            Reset filters
          </Link>
        </div>
      ) : (
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {results.map((listing) => (
            <ListingCard key={listing.id} listing={listing} />
          ))}
        </div>
      )}
    </div>
  );
}
