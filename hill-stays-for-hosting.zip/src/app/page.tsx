import Link from "next/link";
import { SearchBar } from "@/components/SearchBar";
import { ListingCard } from "@/components/ListingCard";
import { getFeatured } from "@/lib/data";
import { CATEGORY_META, type Category } from "@/lib/types";

// Featured listings come from the runtime store, so render on demand.
export const dynamic = "force-dynamic";

const categories: Category[] = ["homestay", "attraction", "activity", "food", "transport"];

export default function HomePage() {
  const featured = getFeatured();

  return (
    <div>
      {/* Hero */}
      <section className="relative">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1600&q=70')",
          }}
        />
        <div className="absolute inset-0 bg-black/45" />
        <div className="relative mx-auto max-w-6xl px-4 py-20 sm:py-28">
          <h1 className="text-3xl sm:text-5xl font-bold text-white max-w-2xl leading-tight">
            Find your perfect stay in Kalimpong &amp; Darjeeling
          </h1>
          <p className="mt-4 text-lg text-white/90 max-w-xl">
            Handpicked homestays, hidden viewpoints, local food and easy travel tips —
            all in one place.
          </p>
          <div className="mt-8 max-w-3xl">
            <SearchBar />
          </div>
        </div>
      </section>

      {/* Category tiles */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-xl font-bold text-gray-900 mb-5">Explore by category</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {categories.map((cat) => {
            const meta = CATEGORY_META[cat];
            return (
              <Link
                key={cat}
                href={`/${meta.urlSegment}`}
                className="rounded-xl border border-gray-100 bg-white p-5 text-center hover:border-brand-500 hover:shadow-md transition-all"
              >
                <div className="text-3xl">{meta.emoji}</div>
                <div className="mt-2 font-medium text-gray-800">{meta.plural}</div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Featured */}
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <h2 className="text-xl font-bold text-gray-900 mb-5">Top rated this season</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {featured.map((listing) => (
            <ListingCard key={listing.id} listing={listing} />
          ))}
        </div>
      </section>
    </div>
  );
}
