# 🏔️ HillStays — Kalimpong & Darjeeling Tourism Platform

A web app where tourists discover **homestays, attractions, things to do, food, and transport**
in Kalimpong and Darjeeling.

This is the **Phase 1 MVP**: a fast, mobile-first discovery site with "request to book via
WhatsApp/call". No database or payments yet — listings come from built-in seed data so it
runs with zero setup.

---

## 🚀 Run it

```bash
cd hill-stays
npm install        # first time only
npm run dev        # start dev server
```

Then open **http://localhost:3000**

Other commands:
```bash
npm run build      # production build
npm start          # run the production build
```

---

## 🧭 What's included (Phase 1)

- **Home page** with hero, search bar, category tiles, and top-rated listings
- **Category pages** (`/homestays`, `/attractions`, `/activities`, `/food`, `/transport`)
  with destination chips, keyword search, and price filter (homestays)
- **Listing detail pages** with photo gallery, full details, and reviews summary
- **Contact / Request-to-book** via WhatsApp + Call buttons (homestays)
- **Admin panel** (`/admin`) to add and delete listings — no code editing needed
- **Mobile-first responsive** design (Tailwind CSS)
- **SEO**: per-page titles/descriptions, clean URLs

---

## 🔐 Admin panel

Go to **http://localhost:3000/admin** (also linked in the footer).

- **Default password:** `admin123`
- **Change it:** create a file `.env.local` in the project root with:
  ```
  ADMIN_PASSWORD=your-strong-password
  ```
  then restart the server.

From the dashboard you can **add a listing** (category-specific fields, with
validation) and **delete** existing ones. New listings appear on the public
site immediately.

**How listings are stored:** they live in `data/listings.json`, which is created
automatically from the seed data on first run. This file is git-ignored, so your
edits stay local. On a read-only serverless host (e.g. Vercel) you'd replace the
store with a database — see below.

---

## 📁 Project structure

```
src/
├── app/
│   ├── layout.tsx              # global layout (header + footer)
│   ├── page.tsx                # home page
│   ├── globals.css             # Tailwind + base styles
│   ├── [category]/
│   │   ├── page.tsx            # category listing + filters
│   │   └── [slug]/page.tsx     # listing detail page
├── components/
│   ├── Header.tsx, Footer.tsx
│   ├── SearchBar.tsx           # homepage search
│   ├── ListingCard.tsx         # listing grid card
│   └── ContactButton.tsx       # WhatsApp/call booking request
│   └── admin/
│       └── AddListingForm.tsx  # add-listing form (client)
├── app/
│   ├── admin/page.tsx          # admin dashboard (login + table + form)
│   └── api/admin/...           # login, list, create, delete endpoints
└── lib/
    ├── types.ts                # data model (Homestay, Attraction, etc.)
    ├── seed.ts                 # initial listings (shipped with the app)
    ├── store.ts                # ⭐ JSON-file read/write (data/listings.json)
    ├── data.ts                 # query helpers used by the pages
    ├── admin.ts                # password check + listing validation
    └── routes.ts               # URL segment ↔ category mapping
```

**To add or edit listings:** use the **admin panel** at `/admin`.
To change the listings that ship by default, edit `src/lib/seed.ts`
(then delete `data/listings.json` so it re-seeds).

---

## 🛣️ Roadmap (what comes next)

| Phase | What | Notes |
|-------|------|-------|
| ✅ **1 — Discovery (this)** | Listings, search, filters, contact | Done |
| **2 — Accounts & engagement** | Tourist login (phone OTP), favorites, reviews | Add Supabase Auth |
| **3 — Booking & payment** | Availability calendar, Razorpay, confirmations | The heavy part |
| **4 — Growth** | Owner self-registration, bilingual, analytics | Later |

### How to move to a real database (Phase 2/3)
The pages only read data through helpers in `src/lib/data.ts`
(`getByCategory`, `getListing`, `searchListings`, etc.). To switch to PostgreSQL:
1. Add Prisma + a Postgres DB (Supabase or Neon).
2. Mirror the types in `src/lib/types.ts` as Prisma models.
3. Rewrite the helper functions in `data.ts` to query the DB instead of the arrays.
   The page components won't need to change.

---

## 🧱 Tech stack
- **Next.js 15** (App Router) + **React 19** + **TypeScript**
- **Tailwind CSS** for styling
- Static generation for speed & SEO

---

## ⚠️ Notes
- Listing photos are royalty-free **Unsplash placeholders** — replace with real photos.
- Phone numbers in seed data are dummy values — replace with real host contacts.
- "Request to book" intentionally has **no payment** in Phase 1 (by design).
