import type { Config } from "tailwindcss";

export default {
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f0f9f4",
          100: "#dcf0e3",
          500: "#1f8a4c",
          600: "#176b3b",
          700: "#11532e",
        },
      },
    },
  },
  plugins: [],
} satisfies Config;
